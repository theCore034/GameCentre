The Catacombs of Solaris
------------------------
by Ian MacLarty
---------------

The goal of the game is to find your favourite room in the catacombs.

There are 3 alternate control schemes:

- Use the arrow keys
- Use the WASD keys and mouse to look
- Use a gamepad: right stick to look, left stick to move

If you get too lost, you can reset by pressing R on your keyboard or B on your gamepad.

Press ESC to quit.

You can find more of my games at http://ianmaclarty.com and my twitter is @muclorty.

Thanks for downloading my game. I hope you enjoy it!

Ian.

